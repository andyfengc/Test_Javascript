var creditApp = angular.module('creditApp');
console.log('init dao');

creditApp.service('creditDao', function(){
    console.log('declare dao');
    this.addCredit = function(){
        console.log('add credit');
    }    
})