var creditApp = angular.module('creditApp');
console.log('init controllers');

creditApp.controller('appController', ['$scope', '$log', function ($scope, $log) {
    console.log('start app');
    $log.debug('start app controller');
}]);

creditApp.controller('addRuleController', ['$scope', '$log', 'creditDao', function ($scope, $log, creditDao) {
   
    $log.debug('start add controller');
    $scope.save = function () {
        creditDao.addCredit();
        alert('saved successfully');
    }
    $scope.test = function () {
        console.log('test');
    }
}]);

creditApp.controller('manageRuleController', ['$scope', '$log', '$state', '$window', function ($scope, $log, $state, $window) {
    $log.debug('start manage controller');
}]);
